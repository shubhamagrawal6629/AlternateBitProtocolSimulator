var searchData=
[
  ['sender_39',['Sender',['../class_sender.html#a5b412cef6be52d0225e6ec1e4846923f',1,'Sender']]]
];
