var searchData=
[
  ['sender_16',['Sender',['../class_sender.html',1,'Sender&lt; TIME &gt;'],['../class_sender.html#a5b412cef6be52d0225e6ec1e4846923f',1,'Sender::Sender()']]],
  ['sender_5fdefs_17',['sender_defs',['../structsender__defs.html',1,'']]],
  ['sending_18',['sending',['../struct_receiver_1_1state__type.html#a07a73a253544ee613b92b04d1bf861f9',1,'Receiver::state_type']]],
  ['state_5ftype_19',['state_type',['../struct_sender_1_1state__type.html',1,'Sender&lt; TIME &gt;::state_type'],['../struct_receiver_1_1state__type.html',1,'Receiver&lt; TIME &gt;::state_type']]]
];
