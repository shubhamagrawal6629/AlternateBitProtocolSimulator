var searchData=
[
  ['internal_5ftransition_36',['internal_transition',['../class_receiver.html#a4d2672f7b941d3a39012fa809740a8ea',1,'Receiver::internal_transition()'],['../class_sender.html#a2749806516a5cddb158154c34ba96462',1,'Sender::internal_transition()']]]
];
