var searchData=
[
  ['output_37',['output',['../class_receiver.html#a61e54d38921755d38a0e846323282cda',1,'Receiver::output()'],['../class_sender.html#ae9dcde5153b33f9b595c69fae72c6d51',1,'Sender::output()']]]
];
