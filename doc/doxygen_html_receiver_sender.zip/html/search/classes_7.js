var searchData=
[
  ['sender_31',['Sender',['../class_sender.html',1,'']]],
  ['sender_5fdefs_32',['sender_defs',['../structsender__defs.html',1,'']]],
  ['state_5ftype_33',['state_type',['../struct_sender_1_1state__type.html',1,'Sender&lt; TIME &gt;::state_type'],['../struct_receiver_1_1state__type.html',1,'Receiver&lt; TIME &gt;::state_type']]]
];
