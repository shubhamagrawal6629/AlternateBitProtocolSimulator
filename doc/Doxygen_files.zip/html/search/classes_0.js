var searchData=
[
  ['ack_5fin_25',['ack_in',['../structsender__defs_1_1ack__in.html',1,'sender_defs']]],
  ['ack_5freceived_5fout_26',['ack_received_out',['../structsender__defs_1_1ack__received__out.html',1,'sender_defs']]]
];
