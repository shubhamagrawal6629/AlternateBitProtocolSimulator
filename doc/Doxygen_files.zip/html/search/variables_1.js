var searchData=
[
  ['preparation_5ftime_49',['PREPARATION_TIME',['../class_receiver.html#a547c2b91b5928ef700f291748bd6113b',1,'Receiver::PREPARATION_TIME()'],['../class_sender.html#a9ea18108dc62c27e70e1766d9a3f0775',1,'Sender::PREPARATION_TIME()']]]
];
