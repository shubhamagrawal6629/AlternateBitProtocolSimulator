var searchData=
[
  ['packet_5fsent_5fout_13',['packet_sent_out',['../structsender__defs_1_1packet__sent__out.html',1,'sender_defs']]],
  ['preparation_5ftime_14',['PREPARATION_TIME',['../class_receiver.html#a547c2b91b5928ef700f291748bd6113b',1,'Receiver::PREPARATION_TIME()'],['../class_sender.html#a9ea18108dc62c27e70e1766d9a3f0775',1,'Sender::PREPARATION_TIME()']]]
];
