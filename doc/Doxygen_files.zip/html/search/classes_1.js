var searchData=
[
  ['control_5fin_27',['control_in',['../structsender__defs_1_1control__in.html',1,'sender_defs']]]
];
